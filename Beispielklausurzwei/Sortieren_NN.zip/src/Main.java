import java.util.Random;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args)
    {
        String auswahl_verfahren, auswahl_generierung, auswahl_ausgabe;
        long[] daten;
        while (true)
        {
            System.out.println("Bitte treffen Sie eine Auswahl:");
            System.out.println("(B)ubbleSort");
            System.out.println("(S)electionSort");
            System.out.println("(I)nsertionSort");
            System.out.println("(E)nde");
            System.out.print("Ihre Auswahl: ");
            auswahl_verfahren = scanner.next().toLowerCase();
            if (auswahl_verfahren.equals("e")) break;
            System.out.println("Bitte treffen Sie eine Auswahl:");
            System.out.println("(G)eneriere Zufallszahlen");
            System.out.println("(E)ingabe von Zahlen");
            System.out.print("Ihre Auswahl: ");
            auswahl_generierung = scanner.next().toLowerCase();
            if (auswahl_generierung.equals("g"))
            {
                daten = generateRandomNumbers();
            }
            else
            {
                daten = readRandomNumbers();
            }
            System.out.println("Bitte treffen Sie eine Auswahl:");
            System.out.println("(A)usgabe der Zahlen (vorher/nachher)");
            System.out.println("(N)ur überprüfen");
            System.out.print("Ihre Auswahl: ");
            auswahl_ausgabe = scanner.next().toLowerCase();
            if (auswahl_ausgabe.equals("a"))
            {
                outputNumbers(daten);
            }
            if (auswahl_verfahren.equals("b"))
            {
                bubbleSort(daten);
            }
            else if (auswahl_verfahren.equals("s"))
            {
                selectionSort(daten);
            }
            else if (auswahl_verfahren.equals("i"))
            {
                insertionSort(daten);
            }
            System.out.println("Die Zahlen wurden" + (isArraySorted(daten) ? " " : " nicht ") + "erfolgreich sortiert.");
            if (auswahl_ausgabe.equals("a"))
            {
                outputNumbers(daten);
            }
        }
    }

    public static long[] generateRandomNumbers()
    {
        int anzahl;
        long max, min;
        System.out.print("Anzahl Zahlen: ");
        anzahl = scanner.nextInt();
        System.out.print("Minimum: ");
        min = scanner.nextLong();
        System.out.print("Maximum: ");
        max = scanner.nextLong();
        long[] daten = new long [anzahl];
        Random zuffi = new Random();
        for  (int i = 0; i < anzahl; i++)
        {
            daten[i] = min + Math.abs(zuffi.nextLong()) % (max - min + 1);
        }
        return daten;
    }

    public static long[] readRandomNumbers()
    {
        int anzahl;
        System.out.print("Anzahl Zahlen: ");
        anzahl = scanner.nextInt();
        long[] daten = new long [anzahl];
        for  (int i = 0; i < anzahl; i++)
        {
            System.out.print((i+1) + ". Zahl: ");
            daten[i] = scanner.nextLong();
        }
        return daten;
    }

    public static void outputNumbers(long[] daten)
    {
        for  (int i = 0; i < daten.length; i++)
        {
            System.out.print(daten[i] + " ");
        }
        System.out.println();
    }

    private static void swap(long[] daten, int i, int j)
    {

    }

    public static boolean isArraySorted(long[] daten)
    {
        return false;
    }
    
    public static void bubbleSort(long[] daten)
    {

    }

    public static void selectionSort(long[] daten)
    {

    }

    public static void insertionSort(long[] daten)
    {

    }
}