package org.example.sortieralgorithmen;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class SortingAlgorithms {

    public static long[] GenerateRandomNumbers(int numbers, long limit)
    {
        long daten[];
        daten = new long [numbers];
        Random zuffi = new Random();
        for(int i = 0; i < daten.length; i++)
        {
            daten[i] = zuffi.nextLong(limit);
        }
        return daten;
    }

    public static boolean isArraySorted(long daten[])
    {

        return true;
    }

    private static void swap(long daten[], int i, int k)
    {
        long tmp = daten[i];
        daten[i] = daten[k];
        daten[k] = tmp;
    }

    public static void bubbleSort(long daten [])
    {

    }

    public static void selectionSort(long daten [])
    {

    }

    public static void insertionSort(long daten [])
    {

    }

    public static void quickSort(long daten[])
    {

    }

    public static void mergeSort(long daten[])
    {

    }

}
